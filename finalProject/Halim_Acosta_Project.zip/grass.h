#include <GL/glew.h>
//#include <stdio.h>

extern GLuint grass_vao;
extern GLuint grass_vbo;


void createGrass();
void renderGrass();