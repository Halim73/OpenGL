#pragma once
#include <GL/glew.h>
//#include <stdio.h>

extern GLuint box_vao;
extern GLuint box_vbo;

void createBox();
void renderBox();