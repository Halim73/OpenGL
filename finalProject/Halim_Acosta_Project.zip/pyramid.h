#pragma once
#include <stdio.h>
#include <GL/glew.h>

void createPyramid();
void renderPyramid();

extern	unsigned int pyramid_vao;
extern  unsigned int box_vbo;